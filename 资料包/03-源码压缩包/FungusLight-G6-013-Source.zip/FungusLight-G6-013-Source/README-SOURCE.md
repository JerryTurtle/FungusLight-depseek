# 《菌灯之下》G6-013 源码包说明

> 本文件同时作为源码压缩包内的 `README-SOURCE.md`。压缩包文件名为 `FungusLight-G6-013-Source.zip`，解压后根目录为 `FungusLight-G6-013-Source/`。

## 1. 包信息

| 项目 | 内容 |
| --- | --- |
| 作品 | 《菌灯之下》 / FungusLight |
| 版本 | v1.0.1 / G6-013 |
| 源快照提交 | 以包内 `SOURCE-MANIFEST.txt` 的"源提交"行为准（本次为 `5a1cabb`；游戏运行文件自发布提交 `b4a1f9c` 起未改动，更完整历史见 Git 仓库 `origin/main`） |
| 引擎 | Godot 4.3 stable（`4.3.stable.official.77dcf97d8`），GL Compatibility |
| 目标平台 | Windows 32 位 / 64 位（双构建） |
| 语言 | 简体中文 |
| 源码规模 | 54 个 GDScript 文件约 13,370 行；32 个 Python/PowerShell 工具；`game/data/*.json` 数据驱动 |
| 压缩包 | 见 `资料包/SHA256SUMS.txt` 与 `资料包/03-源码压缩包/SHA256SUMS.txt` |

## 2. 压缩包内容

```text
FungusLight-G6-013-Source/
├── README-SOURCE.md          本文件
├── SOURCE-MANIFEST.txt       文件清单（路径、字节数）与构建信息
├── AGENTS.md                 项目开发约定
├── LICENSE                   项目代码许可（Apache-2.0）
├── .gitignore / .gitattributes
├── game/                     Godot 4.3 工程根目录
│   ├── project.godot
│   ├── export_presets.cfg
│   ├── data/                 actions / enemies / prologue / review 配置
│   ├── scenes/               boot / campaign / main / 测试与采集场景
│   ├── scripts/              战斗、关卡、UI、存档、工具与测试脚本（52 个 .gd）
│   ├── assets/               original / fonts / audio / props / hud / title / intro / licenses
│   ├── qa/                   工程内测试配置
│   └── DEV_STATE.md
├── tools/                    构建、生成、测试、打包、审计脚本
├── docs/                     交接文档、开发历史、AI 交互记录、G3/G4/G6 说明
├── qa/                       门槛、人工批准、证据（文本）、迁移表
├── 策划输出/                 完整策划方案、历史稿、素材复核
├── 交付文档/                 作品说明（简版）、AI 工具使用说明（副本）
└── AI交互记录/               54 轮汇总、原始聊天、35 组交互列表、开发历史（副本）
```

**包含：** 全部游戏源码、数据、场景、素材、字体、音频、工具脚本、策划、交接文档、AI 交互记录、测试日志与 JSON 证据（文本类）。

**不包含（有意排除）：**

| 排除项 | 原因 |
| --- | --- |
| `.git/`、`deliverables/`、`资料包/`、`Fungus Cave [16x16]/` | 版本库、发布二进制、本资料包、原始素材全集；运行素材已复制到 `game/assets/original/` |
| `game/.godot/`、`__pycache__/`、`qa/local/`、`qa/runtime-profile/` | 缓存、个人副本、运行时隔离目录 |
| `game/autoload/mcp_interaction_server.gd` | 开发期 MCP 交互服务，不进入发布/源码交付 |
| `qa/evidence/**/*.png`（约 107 MB） | 截图证据；完整截图随发布包 `QA/evidence/` 与 Git 仓库保留，文本/JSON/日志证据已包含 |
| 个人存档、设置、审核反馈、日志 | 隐私与可复现性边界 |

## 3. 打开与运行

### 3.1 用 Godot 编辑器

1. 安装 **Godot 4.3 stable**（标准版，非 .NET）。
2. 导入 `game/project.godot`，按 F5 运行。
3. 默认启动场景为 `scenes/boot.tscn`；debug 构建会进入 G2 审核台，release 构建进入正式主线。
4. 首次导入会生成 `game/.godot/` 缓存，属正常现象，不要提交。

### 3.2 直接导出 Windows 包

需要 Godot 4.3 stable 的 Windows 导出模板：

```powershell
# 在仓库根目录
./tools/build.ps1 -BuildId G6-013-local
# 产物：deliverables/G6-013-local/FungusLight.exe + .pck（64 位）
#       deliverables/G6-013-local-32/FungusLight.exe + .pck（32 位，需 windows_release_x86_32.exe 模板）
```

> `tools/build.ps1` 与部分 Python 脚本含本机 Godot 绝对路径（`C:/Software/Godot_v4.3-stable_win64.exe/...`）。换机后需按 `README.md` 的“运行与环境”逐项修改并核实。

### 3.3 运行已发布版本

直接解压 `资料包/01-游戏安装包/FungusLight-G6-013-Release.zip`，双击 `Game/开始游戏.cmd`；无需 Godot 编辑器。

## 4. 依赖

| 用途 | 依赖 |
| --- | --- |
| 运行游戏 | 无外部依赖（引擎打包在 exe 内） |
| 编辑/导出 | Godot 4.3 stable + Windows 导出模板 |
| 素材/音效生成 | Python 3.13 + Pillow 11.3 |
| 构建/打包 | PowerShell 5.1+ / 7 |
| 版本管理 | Git（可选） |
| 字体 | Fusion Pixel 12px（OFL）、Noto Sans SC（OFL） |

## 5. 验证命令

```powershell
# 战斗模型（550 项）
python tools/test_combat.py

# 全套内容/场景/存档/对话/素材/路线（示例编号）
python tools/test_g3_slice.py G6-013-check

# 存档 65 项
python tools/test_save.py G6-013-check

# 路线矩阵（可选，耗时较长）
python tools/test_g4_routes.py

# 发布包审计（构建后；脚本按 deliverables/<BuildId> 读取）
python tools/check_release_package.py G6-013-local
# 五目录布局检查（需先组装到 deliverables/Release）
python tools/check_release_layout.py G6-013-Release G6-013-Release
```

**注意：**

- 不要直接运行 `tools/finalize_g2.py`，它会重写历史报告与门槛。
- 测试输出编号必须显式指定新编号，避免覆盖历史证据。
- 自动化使用 Godot headless/引擎输入注入，不等同于真人键鼠与主观体验验收。

## 6. AI 交互过程记录

压缩包内有两份入口：

1. **`AI交互记录/`**：直接阅读版。
   - `与AI交互内容-汇总.md`：54 轮合并汇总（推荐先读）
   - `AI交互列表-35组.md`：按阶段归纳的 35 组交互
   - `开发历史-G0到G3-001.md`：详细开发历史
   - `与AI交互内容-策划.md`、`-1.md`、`-2.md`、`-3.md`：原始记录
2. **`docs/`**：与仓库一致的原始文档位置（含 G3/G4/G6 说明、发布说明）。

逐轮验证证据在 `qa/evidence/G0`～`G6`（文本类）；截图在发布包 `QA/evidence/`。

## 7. 许可与分发

- **项目代码：** 根目录 `LICENSE`（Apache-2.0）。
- **Godot Engine：** MIT；字体：SIL OFL 1.1。
- **原始 Fungus Cave 素材：** 再分发许可**未核实**；本源码包仅用于本项目验收，公开/商业分发前必须由用户或权利人确认。
- **AI 生成图（标题/开场）：** 生成来源与处理方式见 `game/assets/licenses/SOURCES.md`；再分发范围需确认。
- 详见 `game/assets/licenses/SOURCES.md`、`docs/g6/release/ASSET-RIGHTS.md`；完整的运行环境/依赖/许可说明见本压缩包内 `交付文档/作品说明.md`（资料包 `02-作品说明文档/` 同名副本）。

## 8. 重新生成与校验

源码包由仓库内 `tools/package_delivery.py` 从 Git 跟踪文件重建；它会校验游戏 zip 哈希、写入 `SOURCE-MANIFEST.txt` 并重写两个 `SHA256SUMS.txt`。生成规则见 `资料包/README.md`。校验：

```powershell
Get-FileHash .\FungusLight-G6-013-Source.zip -Algorithm SHA256
Get-Content .\SHA256SUMS.txt
```

哈希、字节数与文件数以 `资料包/SHA256SUMS.txt` 与 `资料包/03-源码压缩包/SHA256SUMS.txt` 为准。
