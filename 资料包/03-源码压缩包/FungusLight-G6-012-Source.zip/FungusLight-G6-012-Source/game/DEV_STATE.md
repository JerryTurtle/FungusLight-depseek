# 菌灯之下 · 当前开发接续

更新：2026-10-19。入口见 [根README](../README.md)，详细过程见 [开发历史](../docs/history/development-through-G3-001.md)。

## 当前状态（G6-012 已通过；用户签署完成）

- G0/G1/G2技术通过；H2用户明确批准，无问题：[原文](../qa/H2-approval.md)。G3、G4已通过；G4-009完成五项试玩修复。
- P0-1 读档修复、P0-2 路线/竞技场修复、P0-3 包/版本/门槛统一均已完成；第三轮按用户 8 项反馈修复箱子开启、休息灯座、冗余机关与 Boss 判定/持续伤害反馈。
- G6-012 第十二轮：传送门去掉外侧粒子/黑色硬边框，改暖色椭圆内部微光与悬浮；碰撞缩到 16×30 内椭圆；粒子纯绘制无碰撞。
- 当前源码验证：14 组引擎套件失败 0（campaign95/g6_release39/g4_state48/g4_boss71/g4_death5/g4_visual15/g4_presentation48/save65/enemies73/dialogue175/props2464/pressure5/route9/skip9）；另 test_combat 550/0、跨进程 restart write2/load8。默认 route 707.7 秒/0 死亡，跳过 607.4 秒/0 死亡；8/8 矩阵为 G6-003 历史基线。
- G6-012 包：本地解压目录 `deliverables/G6-012-Release/`（未跟踪），正式 zip `资料包/01-游戏安装包/FungusLight-G6-012-Release.zip`；exe `66B26A…B7B13`，BGM `boss_theme.wav`，pck/zip 哈希见 `qa/evidence/G6/G6-012-final-package.txt`。旧 `deliverables/Release` 与门禁/验收副本已清理；发布 zip 已纳入 Git，PCK 审计、五目录布局、干净目录 headless 启动通过。交付资料包：`资料包/`（01 安装包、02 作品说明与 AI 工具说明、03 源码 zip + AI 交互记录）；源码 zip 哈希见 `资料包/SHA256SUMS.txt`。
- 接续分支 main；release 构建默认 campaign，debug 构建仍进 G2 审核台。
- G6 已通过：用户在 `qa/G6-approval.md` 勾选“通过”并签名（JeryTurtle，日期按原文 2026.10.49）；逐项字段/哈希栏未填写，哈希见 `qa/evidence/G6/G6-012-final-package.txt`。原始素材/生成图/Boss BGM 再分发许可仍需确认。

## 2026-10-18 第二轮：剧情收敛与成长/证据接线（进行中）

- 用户授权削减剧情，只保留完整逻辑闭环；策划 §5.1/§5.2 已改写，其余系统仍按原策划实现。
- 已接线：S04～S09 短对白；S04/S07/S08 三证据门禁；结局条件与独立 `ending_pre.json`；死亡最近检查点；清场自动存档；`no_elite_battle` 实际计算；M1～M4 策划选项与生命/专注曲线；护灯 P02 后解锁；选强化不再满血；灯击范围恢复 22。
- 验证：test_g4 39/0、test_g4_campaign 88/0、test_g4_death 5/0、test_g6_release 34/0；test_enemies 73/0、test_g4_boss 67/0。该轮 `route_test` 失败（N3-07/N2-07 测试机器人路径/战斗平衡）；P0-2 已修复并重跑，见下方。
- 已接入：T6 双弹投孢、EL2 冲锋/水道、EL1 半血补壳、Boss 2200 HP 三阶段/核心窗口/预警几何，Boss 使用原 BOSS.png；移除主线 hp_mult 缩血。
- 装备：聚束镜/节流镜拾取、工匠扣、澄明镜、余温符、守灯结已接入真实效果；暂停菜单“装备配置”已有灯镜/护符二选一槽位，休息点限定与专属界面待完善。
- HUD 已增加护盾/技能冷却与孢毒剩余时间；Boss 阶段/核心/死亡事件接入轻震、状态提示与反馈环；孢毒新增角色周围脉冲环；装备配置改为休息点可用。
- P03～P09 已加顺序/证据门禁；P03/P04/P05/P06/P07/P08/P09 均有独立对照/顺序交互（选择/开关为主）。
- 回声扫描新增证据/交互物高亮；release 构建拒绝 FUNGUS_SAVE_DIR/--campaign-capture；Release 目录运行产物已清理（zip 仍旧包）；设置新增独立震屏开关。
- 已组装本地候选 `deliverables/G7-Release/{Game,Source,Docs,QA,Licenses}` 与 zip `deliverables/FungusLight-G7-001-Candidate.zip`（SHA256 `4536DCF8…9BB224F`）；exe `66B26AD9…B7B13`、pck `A4FF9901…3408C`；PCK 只读检查无 test/capture/review/MCP/autoload，含 BOSS.png 与语义道具；Game 目录无个人存档/日志；capture_g4 实机截图验证语义道具。未做 release GUI 干净目录全流程。
- 纸张占位按语义拆分：`wall_inscription`/`document`/`puzzle_console`/`evidence_slot`/`npc`；墙壁仍用暗色石砖，不再把纸张图用于墙面。`test_props` 2472/0。
- 待续：其余 12 类特效、route_test 适配（P0-2 已完成）、G7 发布验收。G6/G7 仍 in_progress。

## P0-1 读档校验修复（G6-002，本地修复迭代）

- 根因：`campaign_state.validate` 用当前进度 `skills()/quests()` 比较快照，重启后或读更早存档时会误报“技能/任务不一致”，有效存档无法读取。
- 修复：新增 `skills_for(flags)/quests_for(flags)`，校验改为按快照自身 story 推导；删除重复的技能检查。
- 验证：跨进程重启读档 write 2/0 + load 8/0（修复前 load 8/5，失败日志保留 `qa/evidence/G6/G6-002-prefix-restart-load.log`）；`test_g6_release` 38/0（新增旧档/新实例回读）、`g4_campaign` 88/0、`save` 65/0、`g4` 48/0、`g4_death` 5/0。通过证据 `qa/evidence/G6/G6-002-*`。
- 限制：只修读档，不改变 gates/包/版本；G6/G7 仍 in_progress。P0-2 已在该修复后重跑并修复路线；全量发布验收仍未完成。下一项 P0-3（包/门槛/版本统一）。

## P0-2 当前源码路线修复与矩阵（G6-002）

- 当前 HEAD 首跑复现 N1-03：100.4 秒，机器人在距 EL1 约 27px 处停住；README 的 N3-07/N2-07 与证据不符。
- 修复 route_test：近距补足到 22px、EL2 冲锋/水道回避、N3-04 空导航空洞环形接近、Boss 孢荚/横扫回避、低血药剂、支线装备字段；修掉历史 `relic/token` 访问导致的脚本异常。游戏侧：`PLAYABLE_AREA` 击退夹取、指针场外自施护灯放行、移除 N4-06 结局标记实体碰撞（此前挡住 Boss 视线）。
- 最终：默认 route 674.8 秒/0 死亡；8 条矩阵 A_restore/B_seal/A_alt_seal/B_alt_restore/C05/C06/sidequests/skip 全过（9/9/9/9/9/9/10/9，619.3～706.0 秒）。证据 `qa/evidence/G6/G6-002-route-default.json/.log`、`G6-002-route-matrix.json/.log`、`G6-002-route-progress.md`。
- 全套件：campaign90、g6_release38、g4_state48、g4_boss67、g4_death5、g4_visual12、save65、enemies73、dialogue175、props2472、pressure5、route9、skip9，全 0 失败；另 test_combat549、restart write2/load8。
- 限制：机器人最快 619.3 秒不是 20 分钟真人时长；历史 `test_campaign.gd` 不在当前套件且旧断言已失效，未作为门禁。P0-2 结束时未改包/版本/gates；P0-3 已统一到 G6-002。

## P0-3 G6-002 包/版本/门槛统一（历史）

- 决定以 G6-002 作为正式 G6 候选；本地 G7-001 候选不再作为交付编号。
- 已统一 `project.godot`/`prologue.json` 版本、导出预设、标题默认值、发布文档、`qa/gates.json` 和验收模板到 G6-002。
- 重建 `deliverables/Release/` 五目录与 zip `deliverables/FungusLight-G6-002-Release.zip`；exe `66B26A…B7B13`，pck `06BDF1…EFEB2`，zip `4B0E9B…B930B`。PCK 审计、五目录布局通过；Game 无个人存档/日志。
- 限制：未重跑干净目录 GUI 全流程；20 分钟真人时长未验证；G6 仍 in_progress，用户书面确认前不得标 passed。证据 `qa/evidence/G6/G6-002-release-package.json`、`G6-002-release-layout.json`、`G6-002-final-package.txt`。

## G6-012 第十二轮传送门视觉与碰撞

- 去掉 `draw_portal()` 的外侧大光晕/6 颗环绕光点和地面大反射；只留椭圆内部柔光、3 颗内部微光与 1.5px 悬浮。
- 椭圆轮廓由近黑 `K` 改为暖石 `P`，不再像黑色硬边框；出口/终点共用。
- 光晕/微光/悬浮只调用 `draw_*`，没有新增碰撞；传送门本体碰撞从 26×34 收窄到 **16×30 内椭圆**。
- 验证：默认 route 707.7 秒/0 死亡，跳过 607.4 秒/0 死亡；14 组套件、test_combat550、restart2/8 全 0；`G6-012-portal.png`。
- 包：本地 `deliverables/G6-012-Release/`，正式 zip `资料包/01-游戏安装包/FungusLight-G6-012-Release.zip`。限制：观感/碰撞手感人工目检、20 分钟真人时长、素材/音乐许可未完成；G6 仍 in_progress。

## G6-011 第十一轮技能特效、章节、设置与近战

- 灯击：弧宽 ±1.36、内圈符文、残影/星形/粒子；范围 22→26、角度 90°→130°；上下朝向增加内侧贴身判定，`test_combat` 550/0。
- 净光：三股光丝、灯口符文、端部光晕/光点；灯雨：法阵、落线、光柱、三重冲击环、像素水花。
- 传送门：椭圆外框已去；新增呼吸光晕、地面反射、环绕光点、光缝与 1.5px 悬浮。
- 开场章节改为“序章/第一章/第二章/第三章/终章”，与 `chapter_name()` 一致；设置页去掉长操作说明和自动保存提示，只留必要选项。
- 清理 G6-001～G6-010/G7 过程包，保留门禁审核与 `Release`；当前包 G6-011。
- 验证：默认 route 707.8 秒/0 死亡，跳过 607.1 秒/0 死亡；14 组套件、test_combat550、restart2/8 全 0；特效截图 `G6-011-*`。
- 包：`deliverables/G6-011-Release/`，zip `deliverables/FungusLight-G6-011-Release.zip`。限制：特效构图/听感/设置页、20 分钟真人时长、素材/音乐许可未完成；G6 仍 in_progress。

## G6-010 第十轮传送门、墙位、Boss BGM 与指引

- 传送门：`portal_base()` 只画椭圆轮廓和内部光幕，删除门框/门楣/侧柱/门槛/门框符文；`sealed` 3 帧、`open` 5 帧均无外框，碰撞不变。
- 墙壁：37 房间重排，多数降为 0～1 面原墙并轮换左右位置；N1-02/N2-10/N3-05 保留原墙保证路线，N4-06/N4-07 `walls=[]`。
- BGM：`game/assets/audio/boss_theme.wav` 29.09 秒、44.1kHz 立体声原创循环；`combat_audio` 新增 music，N4-06 播放，离开/标题停止，设置音量同控。
- 顶部指引：`章节 / 房间` → `章节  .  房间`。
- 验证：campaign95/g6_release39/g4_state48/g4_boss71/g4_death5/g4_visual15/g4_presentation48/save65/enemies73/dialogue175/props2464/pressure5/route9（752.2 秒）/skip9（651.4 秒）全 0；test_combat549、restart2/8。实机 N4-06 `music.playing=true`、`loop_mode=1`、walls=0。
- 包：`deliverables/G6-010-Release/`，zip `deliverables/FungusLight-G6-010-Release.zip`；PCK/布局/干净目录 headless 启动通过。限制：传送门构图/墙位/BGM 听感与音量人工目检、20 分钟真人时长、素材/音乐许可未完成；G6 仍 in_progress。

## G6-009 第九轮全局移除三色记录台

- N2-08 泵站控制室删除 `p06_choice`；N3-02 供给回廊删除 `p07_choice`；N1-06 已在 G6-008 删除。数据中已无 `puzzle_console`。
- 同时移除 `prop_art.gd` 的 `puzzle_console` 绘制/偏移/自定义列表，以及 `props_data.json`、`gen_props.py` 的 `puzzle_choice -> puzzle_console` 别名，防止再出现。
- P03/P06/P07 仍分别由 2/2/3 个阀门完成；出口门槛 `P03&S04`、`M3&P06&S07`、`P07` 不变。
- 验证：campaign95/g6_release38/g4_state48/g4_boss71/g4_death5/g4_visual15/g4_presentation48/save65/enemies73/dialogue175/props2464/pressure5/route9（734.6 秒）/skip9（635.4 秒）全 0；test_combat549、restart2/8。
- 包：`deliverables/G6-009-Release/`，zip `deliverables/FungusLight-G6-009-Release.zip`；PCK/布局/干净目录 headless 启动通过。限制：三场景画面/阀门人工目检、20 分钟真人时长、素材许可未完成；G6 仍 in_progress。

## G6-008 第八轮根桥去除三色记录台

- N1-06 根桥删除 `p03_choice`「断根记录对照」；用户截图对应的 `puzzle_console` 三色记录台不再出现。
- P03 仍由 `v01`/`v02` 两个桥压阀完成；东侧出口仍要求 `P03&S04`，S04 由桥头断根切口记录；未删除谜题或门槛。
- `puzzle_console` 保留给 P06/P07；`test_props` 由 2472 降至 2470。
- 验证：campaign95/g6_release38/g4_state48/g4_boss71/g4_death5/g4_visual15/g4_presentation48/save65/enemies73/dialogue175/props2470/pressure5/route9（734.6 秒）/skip9（635.4 秒）全 0；test_combat549、restart2/8。
- 包：`deliverables/G6-008-Release/`，zip `deliverables/FungusLight-G6-008-Release.zip`；PCK/布局/干净目录 headless 启动通过。限制：根桥画面/P03 两阀人工目检、20 分钟真人时长、素材许可未完成；G6 仍 in_progress。

## G6-007 第七轮开始界面与像素字体

- 标题：删除黑框/剧情介绍/回看；全屏透明菜单 + 36% 柔光层，标题 56px 居中、副题 18px，菜单 VBox 垂直居中；按钮无底板无边框，Fusion Pixel 字体，悬停暖金。
- 菜单：新游戏、继续、读取、设置、退出；新游戏仍播放五幕开场。
- 设置入口：`settings_panel.z_index=100`，修复从标题打开设置被 `title_bg` 遮挡；`test_g6_release` 增加 z-index 断言。
- 字体：顶部 `hud` 目标、底部 `status` 操作提示、菜单标题/段落/按钮均显式使用 Fusion Pixel。
- 验证：campaign95/g6_release38/g4_state48/g4_boss71/g4_death5/g4_visual15/g4_presentation48/save65/enemies73/dialogue175/props2472/pressure5/route9（734.6 秒）/skip9（635.4 秒）全 0；test_combat549、restart2/8。
- 包：`deliverables/G6-007-Release/`，zip `deliverables/FungusLight-G6-007-Release.zip`；PCK/布局/干净目录 headless 启动通过。限制：标题/设置入口/像素字体人工目检、20 分钟真人时长、素材许可未完成；G6 仍 in_progress。

## G6-006 第六轮界面与开场优化

- 开场：五幕改为可直接读懂的故事摘要（世界/旧约/禾抬压与砍根/菌群反击/岚下井/三证据/两种选择）；第三幕拆三行。
- 左上 HUD：删除面板与铆钉，改为约 280×128 透明信息层；小头像、生命/精力细条、护灯当前/上限、三瓶药剂、用时、R 药剂/孢毒，文字加描边。
- 右下技能栏：删除面板/标题/格子边框，五个 32×32 图标横排；保留冷却、锁标、精力不足变暗、护灯青色下划线，费用 10px“耗 N”。
- 净光：沿光路收集所有敌方受击体，每人结算一次，遇墙截断；`test_combat` A04 双目标都掉 24 血，549 项 0 失败。
- 标题：`game/assets/title/title_bg.png`，320×180、96 色量化后最近邻放大到 1280×720；只在新标题显示。
- 设置：420×540、主字号 18；标题 28、操作/保存 12、返回 18/36；打开时隐藏 HUD/小地图。
- 验证：campaign95/g6_release38/g4_state48/g4_boss71/g4_death5/g4_visual15/g4_presentation47/save65/enemies73/dialogue175/props2472/pressure5/route9（734.6 秒）/skip9（635.4 秒）全 0；test_combat549、restart2/8。
- 包：`deliverables/G6-006-Release/`，zip `deliverables/FungusLight-G6-006-Release.zip`；PCK/布局/干净目录 headless 启动通过。限制：开场/HUD/技能栏/标题/设置/净光多目标与 20 分钟真人时长未人工验收；G6 仍 in_progress。

## G6-005 第五轮全文本审校

- 剧情：水脉先降→禾抬泵压→根须堵管→禾签砍根令→菌群反击；L03 区分侧根渴裂/主根斧痕，S04/S07/L10 互证。S08 只留残片并注明“已够作证”，L12 补全留路与违约代价。
- 人物：S07 让禾承认抬压/砍根；L14 挂到最后灯座；两结局补禾的残页去向；绒留在营地最后一盏灯，封存结局写灯灭后回水脉；L08 改为腿被梁砸伤并铺垫旁室两名伤员，砾的结局有依据。
- 未挂载文本 L05/L09/L11/L14 挂到根桥、合流通道、王庭外环、最后灯座；32 个休息灯座仍离出口 ≥60px 且 E 最低优先级。
- 目标/提示：N1-04 出口改“菌灯井”，N4-04 空外廊不再说“两段守卫”，N3-02/N4-03/M3/N2-08 与现场一致；玩家文本去掉 S08/M1/manual_1 等内部 ID。
- 界面：精力/药剂/护壳/灯线术语统一；HUD 加护灯上限、用时、技能“耗 N”并修正右侧越界；暂停/装备面板加高；存档区分无档/损坏/仅备份；保存/读取提示写明槽位；设置删去方向键并改 R 药剂；开场不剧透三证据/结局，标题回看最后一页提示返回标题。
- 验证：campaign95/g6_release38/g4_state48/g4_boss71/g4_death5/g4_visual15/g4_presentation45/save65/enemies73/dialogue175/props2472/pressure5/route9（735.1 秒）/skip9（635.9 秒）全 0；test_combat549、restart2/8。
- 包：`deliverables/G6-005-Release/`，zip `deliverables/FungusLight-G6-005-Release.zip`；PCK/布局/干净目录 headless 启动通过。限制：全文本/HUD/开场/暂停/装备面板未人工验收；窗口化两结局、20 分钟真人时长、素材许可未完成；G6 仍 in_progress。

## G6-004 第四轮用户反馈（剧情/HUD/技能/开场）

- 第 1 项：32 个休息灯座全部移到房间安全角，离最近出口 ≥60px；`nearest_object` 将休息设为最低交互优先级，出口/宝箱/阀门/剧情物不再被抢 E。路线在 V09、V12 的误触休息已修复。
- 第 2 项：以 `qa/evidence/G6/G6-012-story-review.md` 审稿，统一“灯网/水脉、旧约三句、禾抬压并签砍根、菌王是旧王留声、母体是根心新意志”；S01～S09、L01～L20 全部重写，新增 S10 Boss 战后，两结局尾声扩为 7～8 句；S08/L12 的残片/全文关系在 G6-005 修正；任务日志合流改看 S06。
- 第 3 项：`campaign_hud.gd` 像素 HUD：头像、生命/精力、护灯/护盾、三瓶药剂满/空、药剂饮用进度；治疗事件绿色 `+生命` 数字与环状反馈。
- 第 4 项：右下技能栏五枚 24px 图标（灯击/净光/护灯/灯雨/闪避），按键、名称、精力消耗、冷却遮罩/秒数、未解锁锁标、护灯激活描边。
- 第 5 项：`intro_cinematic.gd` 五幕 1280×720 像素插画，渐入/推镜/字幕/进度点，Enter/空格/左键推进，Esc 跳过；标题“开场故事”回看。
- 验证：campaign95/g6_release38/g4_state48/g4_boss71/g4_death5/g4_visual15/g4_presentation30/save65/enemies73/dialogue175/props2464/pressure5/route9/skip9 全 0；test_combat549、restart2/8。默认 725.9 秒、跳过 635.9 秒、0 死亡；8/8 矩阵未重跑，沿用 G6-003 历史基线。
- 包：G6-004；PCK/布局/干净启动见 `qa/evidence/G6/G6-004-*`。限制：HUD/开场/剧情未人工验收；窗口化两结局与 20 分钟真人时长未完成；G6 仍 in_progress。

## G6-003 用户反馈修复与发布候选

- 第 1 项：EL2 冲锋/水道伤害经真实 N2-07 场景探针确认存在（20/10×2）；原缺的是 dot 反馈，已补伤害数字与受击音。
- 第 2 项：侧支/装备箱按自身领取标记切换 `chest` 开启帧；test_g4_campaign 92/0 覆盖。
- 第 3～5/7 项：删除 N2-02 p04_choice、N2-04 p05_choice、N3-05 p08_slots、N4-03 p09_choice 四处冗余对照台/证据台；P04/P05/P08/P09 仍可由阀门开关完成。
- 第 6 项：32 个休息灯座移到前向/唯一出口侧；灯座不再作为实体阻挡，route_test 改为读取房间实际 rest 对象，避免卡出口。
- 第 8 项：Boss 取消核心窗口伤害门，`enemy_hurt_rect` 以 155×135 素材的 0.5 倍整图（77.5×67.5）为判定区；灯击/净光/灯雨共用。
- 验证：默认 route 674.4秒/0死亡，8/8 matrix 612.3～728.3秒；campaign92/g6_release38/g4_boss71/g4_visual14/save65/enemies73/dialogue175/props2464/pressure5 + test_combat549、restart2/8。
- 包：`deliverables/Release/`，zip `deliverables/FungusLight-G6-003-Release.zip`；exe `66B26A…B7B13`，pck `0495EA…77491B`，zip `21E1CD…BBC0A`。PCK/布局/干净启动烟测通过。
- 限制：窗口化两结局与 20 分钟真人时长未验收；G6 仍 in_progress。证据 `qa/evidence/G6/G6-003-feedback-checks.json`、`G6-003-route-matrix.json`、`G6-003-feedback-suite.log`。

## 验收完成：G6-012 已通过（用户签署）

P0-1/P0-2/P0-3 与 G6-004～G6-012 反馈修复已完成，G6-012 已由用户签署通过。以下清单保留作为验收记录：

1. 干净目录首次启动；标题居中/无黑框/像素字体，无剧情介绍与开场回看，点击“设置”能正常打开；新游戏（含五幕开场/跳过）、设置持久化、双槽隔离、坏档恢复、死亡三选项。
2. 开场五幕是否一眼读懂世界/旧约/禾抬压与砍根/菌群反击/三证据/两种选择；全文本通读 S01～S10、L01～L20、两结局 9 句尾声。
3. 左上透明 HUD 与右下无框技能栏：尺寸/透明度/字号、生命/精力/护灯/药剂/用时、冷却/锁标/“耗 N”，确认不遮挡场景。
4. 净光光路：直线上多个敌人同时掉血、每人只结算一次、墙后敌人不掉血；两结局各走一次，确认尾声/统计/返回标题/结局前备份。
5. 传送门暖色椭圆/内部微光/无外侧粒子/外圈无碰撞、灯击/净光/灯雨特效、近战上下内侧命中、Boss BGM、开场章节、精简设置；37 节点、字体/标签、暂停/装备完整可见。
6. 双槽/坏档/仅备份提示、WASD 键位说明、设置持久化；确认原始 Fungus Cave 素材与开场/标题生成图再分发范围；G5单独阶段按用户指示跳过，音乐与完整按键重设列为已知边界。
7. 用户书面确认后，才把 G6 标 passed 并写 human_approval。

## 证据与限制

- [门槛](../qa/gates.json)、[G2报告](../qa/evidence/G2/G2-007-gate-report.md)、[G4-008报告](../qa/evidence/G4/G4-008-progress.md)。
- G4 人工验收包：`deliverables/G4-008-Acceptance/G4-Acceptance.cmd`、`G4-Acceptance.md`、`G4-Checklist.md`；压缩包 `deliverables/G4-008-Acceptance.zip`。
- G2的549模型/118战斗集成/50审核集成、帧率回放和900秒负载是历史基线，不等于G3完成。
- 用户目录可能使用exe旁后备位置；原生集成非OS键鼠自动化；原素材授权待核实；主线/Boss/G6未完成。

## 本轮目录整理

- 证据移入qa/evidence/G0～G3；tools/qa_paths.py统一输出路径，门槛与当前文档引用已同步。
- qa/local保存本机复现副本、模板包和探针；qa/runtime-profile保留隔离用户数据，不删除个人数据和交付包。
- 原始证据字节保持不变，旧路径与SHA256见qa/maintenance/path-migration.json；历史日志内绝对路径表示原环境，不改写。
- 历史接续归档docs/history，当前文件只保留可执行状态。本轮验证见qa/maintenance/directory-check.json：256份文件哈希不变、66项门槛证据可定位、22个当前文档链接和22个Python语法检查通过、PowerShell构建脚本语法通过；新路径Godot存档65项通过，75个游戏运行文件字节不变。无战斗/表现改动或阶段升级。

## 交付与中断

每轮验证后更新本文件及必要门槛，用Conventional Commits提交并推送；中断记录未完成与失败验证。自动化不随仓库自动迁移，额度不可用时等待，不绕过限额。

## README与策划接续核对

2026-10-17：已对照代码、actions.json、历史实现与G2/G3证据，在README和当前策划零章同步列出I01～I16实现清单、现值动作表、存档契约、尚未实现功能与G3～G6验收路线。策划旧的“仅素材完成/全部未通过/音频缺失/审核台待开发”已修正，M1位置明确为N0-02。无新增游戏功能，下一项仍G3-002。文档核对证据见qa/maintenance/handoff-docs-check.json；后续两份快照须同步维护。

## G3-002 最新接续

四节点序章/P01/S01～S03/M1/真实战斗教学/主线存档已接入，42项状态与引擎事件检查通过。运行deliverables/G3-002/FungusLight.exe -- --campaign。报告qa/evidence/G3/G3-002-progress.md。下一轮补R治疗、正式交互物图块、动态目标提示及存档/剧情恢复边界，然后投孢/冲锋/精英与完整切片。E03只有T1，T5未实现；未证明10～15分钟或A18完成。五小时额度在用户本轮要求中以剩余10%为停止线，需定期查询，不能把本次提交当作停止授权。

## G3-003 最新接续

R治疗、药剂、动态目标与交互物已接入；78序章/549模型/65存档/118导出集成通过，帧率回放一致。报告qa/evidence/G3/G3-003-progress.md。下一项G3-004新敌人专项，并关闭主线未解锁灯雨瞄准圈；仍缺正常输入整段路线和10～15分钟实测。额度上次查询剩余65%，继续按用户要求推进至10%停止线。

## G3-004 最新接续

T2/T3/T4/T5/EL1专项、孢毒/攻击名额与预警已实现；E03接入T5。35敌人/78序章/549模型/118原生和回放通过。首轮并发GUI干扰灯雨测试，独立重跑通过；后续窗口工具串行并等待进程。报告qa/evidence/G3/G3-004-progress.md。下一项G3-005正常输入路线和恢复边界，完整矿道/10～15分钟仍欠缺。额度最近剩余37%，继续推进但预留提交/接续时间。

## G3-005 最新接续与额度停止线

当前包deliverables/G3-005，双击Play-Prologue.cmd或Enemy-Arena.cmd。83序章/35敌人/65存档通过；模型/原生/回放沿用G3-004未修改部分。下一项G3-006正常输入全路线/实测、矿道扩展和完整验收。用户要求本次五小时额度剩10%停止；最后收尾阶段已接近该线，不再启动新实现，后续恢复后接续。报告qa/evidence/G3/G3-005-progress.md。

## G3-006 接续（历史）

方舟像素字体 Ark Pixel（G3-007 因缺字改为 Fusion Pixel）＋底部 RPG 对话框＋交互物像素素材/待机粒子＋N1-01/N1-02 菌洞切片＋P02 三导光机关＋数据驱动遭遇已接入；快速路线在引擎输入下 89.6 秒完成 N0-01→N1-02，0 死亡。129 序章/65 存档/35 敌人/167 对话/2089 素材/8 路线检查、118 原生导出、50 审核台、30/60/144 回放全部通过；包为 deliverables/G3-006。报告 qa/evidence/G3/G3-006-progress.md。

## G3-007 接续（历史）

按玩家八项反馈：字体改用缝合像素 Fusion Pixel（原 Ark 缺“燃”等 12 字）、物件名牌/HUD 透明背景＋描边、绒名字移到头顶、粒子减量减速降亮、尸体 3.5 秒后淡出、矿工刻字移到出口旁、矿道墙壁改砖格、导光未对准也有方向箭头与“（上/右/下/左）”标注。132 序章/65 存档/35 敌人/175 对话/2059 素材/8 路线检查、118 原生导出、50 审核台、30/60/144 回放通过；快速路线 84.6 秒/0 死亡。包 deliverables/G3-007，报告 qa/evidence/G3/G3-007-progress.md。

## G3-008 接续（历史）

床铺移到地表层并在新游戏/床铺休息播放苏醒演出（初始站位 66,124）；储物箱/木箱堆/桶/柜/书架加入矩形碰撞，玩家/敌人/寻路/出生/存档共用；交互视线改用 clear_wall_line，避免箱子挡住 E；绒加入圆形碰撞（半径 7）；门/切片边界帧速放慢 3 倍，灯池 6→18 tick、导光光点 22→40 tick，门牌显示“未开启/可通过/不可通行”，未开启边界有锁/冷色门缝且按 E 提示未接通，开启后缓慢暖光/上浮光点。137 序章/65 存档/35 敌人/175 对话/2059 素材/8 路线检查、118 原生导出、50 审核台、30/60/144 回放通过；快速路线 83.2 秒/0 死亡。包 deliverables/G3-008。

## G4-008 六过渡区、战斗表现与试玩修复（G4通过）

按用户要求把时长目标改为20分钟。新增 N1-08 菌灯井、N1-07 根桥下层、N2-09 泵站回廊、N2-10 试验段外廊、N3-07 王庭侧廊、N3-08 调压前厅与 E31-E36；节点37/遭遇37；Boss400。88场景/34状态/5Boss/65存档/35敌人/175对话/2450素材/5压力/9路线/9跳过、118原生、50/50审核台、回放通过；正常487.4秒、跳过464.4秒。自动8.6分钟不是20分钟人类时长；G4已通过；用户确认20分钟时长，G4-008修复试玩问题。验收包deliverables/G4-008-Acceptance/。下一项G5。

## G4-001 全主线结构首版（历史）

G4-001 已搭出五章31节点、30主线遭遇、P01-P09、M1-M4、6装备、Q1/Q2支线、第二章A/B双支路、三阶段Boss与两结局。76场景/34状态/65存档/35敌人/175对话/2508素材/5压力/9路线/9跳过、118原生、50/50审核台、30-60-144回放通过；正常路线404.3秒、跳过352.7秒、0死亡。限制：快速路线仅6.7分钟（目标≥60）、Boss 150生命为路线验证版、C01-C06/四条合法路线与真人时长未完成，G4 仍 in_progress。包deliverables/G4-001，报告qa/evidence/G4/G4-001-progress.md。下一项G4-002。

## G3-013 G3 通过（历史）

G3 不再缺工程项。G3-013 补齐：整段 Tab 跳过 8/8（98.6 秒，正常 127.8 秒）；一次联合回读剧情 E03、M1、P02、HP 37、专注 5、药剂 1 与节点；N1-05 实际房间 10 追兵 600 步 A15；180 序章/65 存档/35 敌人/175 对话/2178 素材/5 窄门压力/8 路线/8 跳过；原生 118、审核台 50/50、30/60/144 回放一致。玩家确认 10～15 分钟；`qa/gates.json` G3 passed，remaining 清空。限制：G3 只到开发切片边界“菌根深处”，G4～G6、Boss、完整主线与最终验收未完成。下一项 G4-001。

## G3-012 接续（历史）

玩家实测 G3-011 约 8 分钟。本轮新增 N1-04 菌根裂口（L03、E09 T1×2、E10 T5）与 N1-05 灯根祭坛（L04、E11 T1×2＋T5），终点迁到灯根祭坛；ENCOUNTERS 扩到 12 项，旧档显式拒绝。173 序章/65 存档/35 敌人/175 对话/2178 素材/5 压力/8 路线检查、118 原生导出、50/50 审核台、30/60/144 回放通过；快速路线 127.8 秒/0 死亡。包 deliverables/G3-012，报告 qa/evidence/G3/G3-012-progress.md。限制：需玩家复测新时长是否达到 10～15 分钟；整段跳过/奖励回读真人验收未完成。下一项 G3-013。

## G3-011 接续（历史）

新增 N1-03 菌根前厅（P02 后从 N1-02 东门进入）；E07 主线 T3（HP×0.8）、E08 守门者 EL1（HP×0.25、2 层护壳），清场后东侧石拱开放，切片边界移到前厅。ENCOUNTERS 扩展到 9 项，旧开发档显式拒绝。新增 A15 压力：10 追兵/窄门/动态门/900 步，5 项通过（528 路径查询、1 名跨门、约 6.3s）。154 序章/65 存档/35 敌人/175 对话/2162 素材/5 压力/8 路线检查、118 原生导出、30/60/144 回放通过；审核台 49/50，唯一失败为本机 Windows 剪贴板被占用（非游戏逻辑）。快速路线 100.5 秒/0 死亡。包 deliverables/G3-011，报告 qa/evidence/G3/G3-011-progress.md。限制：10～15 分钟真人时长、整段跳过/奖励回读真人验收、A15 实际房间压力未完成。下一项 G3-012。

## G3-010 接续（历史）

所有房间出口与切片边界统一为石拱传送门（exit 别名改为 portal），封印/开启两态、棕色石砖、苔藓/符文，与墙体/图集家具同源。床铺/休息灯座/火把/门/传送门按整块脚印碰撞，玩家/敌人/寻路/出生/存档共用；初始站位 (72,136)，路线/交互点在碰撞体外。门牌统一“通往/返回 目的地”无箭头；火把火焰居中贴合杆顶。142 序章/65 存档/35 敌人/175 对话/2156 素材/8 路线检查、118 原生导出、50 审核台、30/60/144 回放通过；快速路线 85.5 秒/0 死亡。包 deliverables/G3-010，报告 qa/evidence/G3/G3-010-progress.md。限制：仍需真人确认石拱/碰撞/火把观感与 10～15 分钟时长；A15 压力、T3/精英主线连续应用、整段跳过/奖励回读未完成。下一项 G3-011。

## G3-009 接续（历史）

床铺整块/休息灯座/火把/出口门/切片传送门加入碰撞，玩家/敌人/寻路/出生/存档共用；初始站位改到床右下 (72,136)，路线与交互点移到碰撞体外。切片边界改用自绘棕石拱传送门（28×38，砖缝/苔藓/符文，封印 3 帧、开启 5 帧慢动画），不再用木制矿门；门牌删除箭头，统一“通往 X/返回 X”，E 提示直接给目的地；火把火焰原点从 (0,-23) 改为 (-1,-22) 居中贴合杆顶。142 序章/65 存档/35 敌人/175 对话/2156 素材/8 路线检查、118 原生导出、50 审核台、30/60/144 回放通过；快速路线 83.6 秒/0 死亡。包 deliverables/G3-009（Play-Prologue.cmd / Enemy-Arena.cmd），报告 qa/evidence/G3/G3-009-progress.md。限制：仍需真人确认碰撞手感、传送门美术与火把位置；A15 压力、T3/精英主线连续应用、整段跳过/奖励回读与 10～15 分钟时长未完成。下一项 G3-010。
