﻿# 菌灯之下 G6-012 发布包

- Game/：可直接运行的 Windows 构建
- Source/：Godot 4.3 工程（无缓存/无 MCP autoload）
- Docs/：操作、验收、已知问题、素材边界
- QA/：AI 验证证据与哈希
- Licenses/：项目、引擎、字体与素材来源

首次运行请看 Docs/操作说明.md；最终人工验收看 QA/验收说明.md。
