﻿# 《菌灯之下》G6-012 源工程

打开方式：用 Godot 4.3 stable 导入本目录的 game/project.godot。
发布运行文件在 ../Game/；本目录不含 .godot 缓存、MCP 开发 autoload 或个人存档。
像素字体：assets/fonts/FusionPixel12px-zh_hans.ttf（OFL，见 ../Licenses）。
