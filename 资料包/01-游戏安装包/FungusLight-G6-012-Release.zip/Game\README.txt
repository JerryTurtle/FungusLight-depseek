﻿《菌灯之下》G6-012

双击 FungusLight.exe 或 开始游戏.cmd。
FungusLight.exe 与 FungusLight.pck 必须保持同目录。
操作与存档说明见 ../Docs/操作说明.md。
构建哈希见 ../QA/SHA256SUMS.txt。
